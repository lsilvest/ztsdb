setGeneric("?", function(e1, e2) standardGeneric("?"))
setMethod("?",
          signature("Rcpp_Zconnection"),
          function (e1, e2) {
              e1$query(deparse(substitute(e2)), substitute(e2), parent.frame())
          })
